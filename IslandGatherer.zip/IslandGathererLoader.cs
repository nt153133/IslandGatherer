﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Media;
using ff14bot;
using ff14bot.AClasses;
using ff14bot.Behavior;
using ff14bot.Helpers;
using ICSharpCode.SharpZipLib.Zip;
using LlamaLibrary;
using LlamaLibrary.Helpers;
using LlamaLibrary.Logging;
using LlamaLibrary.Memory;
using Newtonsoft.Json.Serialization;
using TreeSharp;
using Action = System.Action;

namespace TestCompileLoader;

public class IslandGathererLoader : BotBase
{
    private const string ProjectName = "IslandGatherer";

    private const string VersionFileName = "Version.txt";

    private const string CompiledAssemblyName = $"{ProjectName}.dll";

    private const string VersionUrl = @$"https://{ProjectName}.llamaserver.com/{VersionFileName}";
    private const string DataUrl = @$"https://{ProjectName}.llamaserver.com/{ProjectName}.zip";

    private static readonly LLogger Log = new(ProjectName, Colors.Lime);

    private static readonly string ProjectAssembly = Path.Combine(LoaderFolderName, $@"{CompiledAssemblyName}");

    private static readonly object Locker = new();
    private static readonly string VersionPath = Path.Combine(LoaderFolderName, VersionFileName);

    private static string _name;
    private static PulseFlags _pulseFlags;
    private static Action _onButtonPress;
    private static Action _start;
    private static Action _stop;
    private static bool _isAutonomous;
    private static bool _wantButton;
    private static bool _requiresProfile;

    private static bool _updated;
    private Action _clear;
    private Func<Composite> _getRoot;

    public IslandGathererLoader()
    {
        lock (Locker)
        {
            if (_updated)
            {
                return;
            }

            _updated = true;
        }

        Task.Run(async () => { await Update(LoaderFolderName); }).Wait();

        try
        {
            Unblock(ProjectAssembly);
        }
        catch (Exception e)
        {
            Log.Error("Failed to unblock");
            Log.Exception(e);
        }

        Load();
    }

    private static string LoaderFolderName => GeneralFunctions.SourceDirectory().FullName;
    public override Composite Root => _getRoot();
    public override string Name => _name;
    public override bool IsAutonomous => _isAutonomous;
    public override bool WantButton => _wantButton;
    public override bool RequiresProfile => _requiresProfile;
    public override PulseFlags PulseFlags => _pulseFlags;

    public override void OnButtonPress()
    {
        _onButtonPress?.Invoke();
    }

    public override void Start()
    {
        _start?.Invoke();
    }

    public override void Stop()
    {
        _stop?.Invoke();
    }

    private void Load()
    {
        Log.Information("Starting constructor");

        RedirectAssembly();

        Log.Information("Redirected assemblies");

        if (!File.Exists(ProjectAssembly))
        {
            Log.Error($"Can't find {ProjectAssembly}");
            return;
        }

        var assembly = LoadAssembly(ProjectAssembly);
        if (assembly == null)
        {
            return;
        }

        Log.Information($"{assembly.GetName().Name} v{assembly.GetName().Version} loaded");
        Type baseType;
        try
        {
            baseType = assembly.DefinedTypes.FirstOrDefault(i => typeof(ICompiledBotbase).IsAssignableFrom(i));
        }
        catch (Exception e)
        {
            Log.Exception(e);
            return;
        }

        if (baseType == null)
        {
            Log.Error("Base type is null");
            return;
        }

        //dispatcher.BeginInvoke(new Action(() =>
        //{
        ICompiledBotbase compiledAsyncBotbase;
        try
        {
            compiledAsyncBotbase = (ICompiledBotbase)Activator.CreateInstance(baseType);
        }
        catch (Exception e)
        {
            Log.Exception(e);
            return;
        }

        _name = compiledAsyncBotbase.Name;
        _start = compiledAsyncBotbase.Start;
        _stop = compiledAsyncBotbase.Stop;
        _onButtonPress = compiledAsyncBotbase.OnButtonPress;
        _pulseFlags = compiledAsyncBotbase.PulseFlags;
        _wantButton = compiledAsyncBotbase.WantButton;
        _requiresProfile = compiledAsyncBotbase.RequiresProfile;
        _isAutonomous = compiledAsyncBotbase.IsAutonomous;
        _getRoot = compiledAsyncBotbase.GetRoot;
    }

    private static Assembly LoadAssembly(string path)
    {
        if (!File.Exists(path))
        {
            return null;
        }

        Assembly assembly = null;
        try
        {
            assembly = Assembly.LoadFrom(path);
        }
        catch (Exception e)
        {
            Logging.WriteException(e);
        }

        return assembly;
    }

    private static void RedirectAssembly()
    {
        AppDomain.CurrentDomain.AssemblyResolve += (sender, args) =>
        {
            var name = Assembly.GetEntryAssembly()?.GetName().Name;
            var requestedAssembly = new AssemblyName(args.Name);
            return requestedAssembly.Name != name ? null : Assembly.GetEntryAssembly();
        };

        AppDomain.CurrentDomain.AssemblyResolve += (sender, args) =>
        {
            var requestedAssembly = new AssemblyName(args.Name);
            return requestedAssembly.Name != "GreyMagic" ? null : Core.Memory.GetType().Assembly;
        };

        AppDomain.CurrentDomain.AssemblyResolve += (sender, args) =>
        {
            var requestedAssembly = new AssemblyName(args.Name);
            return requestedAssembly.Name != "LlamaLibrary" ? null : typeof(OffsetManager).Assembly;
        };

        AppDomain.CurrentDomain.AssemblyResolve += (sender, args) =>
        {
            var requestedAssembly = new AssemblyName(args.Name);
            return requestedAssembly.Name != "Newtonsoft" ? null : typeof(JsonContract).Assembly;
        };
    }

    private static async Task Update(string loaderFolderName)
    {
        var local = GetLocalVersion();
        var data = await TryUpdate(local);
        if (data == null)
        {
            return;
        }

        try
        {
            Clean(loaderFolderName);
        }
        catch (Exception e)
        {
            Log.Exception(e);
        }

        try
        {
            Extract(data, loaderFolderName);
        }
        catch (Exception e)
        {
            Log.Exception(e);
        }
    }

    private static string GetLocalVersion()
    {
        if (!File.Exists(VersionPath))
        {
            return null;
        }

        try
        {
            var version = File.ReadAllText(VersionPath);
            return GetNumbers(version);
        }
        catch
        {
            return null;
        }
    }

    private static void Clean(string directory)
    {
        foreach (var file in new DirectoryInfo(directory).GetFiles())
        {
            file.Delete();
        }

        foreach (var dir in new DirectoryInfo(directory).GetDirectories())
        {
            dir.Delete(true);
        }
    }

    private static async Task<byte[]> TryUpdate(string localVersion)
    {
        try
        {
            using var client = new HttpClient();
            var stopwatch = Stopwatch.StartNew();
            var version = GetNumbers(await client.GetStringAsync(VersionUrl));
            Log.Information($"Local: {localVersion} | Latest: {version}");

            if (string.IsNullOrEmpty(version) || version.Equals(localVersion))
            {
                return null;
            }

            Log.Information($"{ProjectName} Updating....");
            using var response = await client.GetAsync(DataUrl);
            if (!response.IsSuccessStatusCode)
            {
                Log.Information($"[Error] Could not download {ProjectName}: {response.StatusCode}");
                return null;
            }

            using var inputStream = await response.Content.ReadAsStreamAsync();
            using var memoryStream = new MemoryStream();
            await inputStream.CopyToAsync(memoryStream);

            stopwatch.Stop();
            Log.Information($"Download took {stopwatch.ElapsedMilliseconds} ms.");

            return memoryStream.ToArray();
        }
        catch (Exception e)
        {
            Log.Information($"[Error] {e}");
            return null;
        }
    }

    private static string GetNumbers(string input)
    {
        return new string(input.Where(c => char.IsDigit(c) || c == '.').ToArray());
    }

    private static void Extract(byte[] files, string directory)
    {
        using (var stream = new MemoryStream(files))
        {
            var zip = new FastZip();
            var previous = ZipConstants.DefaultCodePage;
            ZipConstants.DefaultCodePage = 437;
            zip.ExtractZip(stream, directory, FastZip.Overwrite.Always, null, null, null, false, true);
            ZipConstants.DefaultCodePage = previous;
        }
    }

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool DeleteFile(string name);

    private static bool Unblock(string fileName)
    {
        return DeleteFile(fileName + ":Zone.Identifier");
    }
}