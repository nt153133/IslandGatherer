﻿using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Media;
using Buddy.Coroutines;
using ff14bot;
using ff14bot.AClasses;
using ff14bot.Behavior;
using ff14bot.Helpers;
using ff14bot.Managers;
using LlamaLibrary;
using LlamaLibrary.Helpers;
using LlamaLibrary.Logging;
using LlamaLibrary.Memory;
using Newtonsoft.Json.Serialization;
using TreeSharp;
using Action = System.Action;

namespace TestCompileLoader
{
    public class IslandGathererLoader : BotBase
    {
        private static string LoaderFolderName => GeneralFunctions.SourceDirectory().FullName;
        private const string CompiledAssemblyName = "IslandGatherer.dll";

        private static readonly LLogger Log = new LLogger("IslandGatherer", Colors.Lime);

        private static readonly string _projectAssembly = Path.Combine(LoaderFolderName, $@"{CompiledAssemblyName}");

        public override Composite Root => _getRoot();

        private static string _name;
        private static PulseFlags _pulseFlags;
        private static Action _onButtonPress, _start, _stop;
        private static bool _isAutonomous;
        private static bool _wantButton;
        private static bool _requiresProfile;
        private Func<Composite> _getRoot;
        private Action _clear;

        public override string Name => _name;
        public override void OnButtonPress() => _onButtonPress?.Invoke();
        public override void Start() => _start?.Invoke();
        public override void Stop() => _stop?.Invoke();
        public override bool IsAutonomous => _isAutonomous;
        public override bool WantButton => _wantButton;
        public override bool RequiresProfile => _requiresProfile;
        public override PulseFlags PulseFlags => _pulseFlags;

        public IslandGathererLoader()
        {
            Log.Information("Starting constructor");

            RedirectAssembly();

            Log.Information("Redirected assemblies");

            if (!File.Exists(_projectAssembly))
            {
                Log.Error($"Can't find {_projectAssembly}");
                return;
            }

            var assembly = LoadAssembly(_projectAssembly);
            if (assembly == null)
            {
                return;
            }

            Type baseType;
            try
            {
                baseType = assembly.DefinedTypes.FirstOrDefault(i => typeof(ICompiledBotbase).IsAssignableFrom(i));
            }
            catch (Exception e)
            {
                Log.Exception(e);
                return;
            }

            if (baseType == null)
            {
                Log.Error("Base type is null");
                return;
            }

            ICompiledBotbase compiledAsyncBotbase;
            try
            {
                compiledAsyncBotbase = (ICompiledBotbase) Activator.CreateInstance(baseType);
            }
            catch (Exception e)
            {
                Log.Exception(e);
                return;
            }

            _name = compiledAsyncBotbase.Name;
            _start = compiledAsyncBotbase.Start;
            _stop = compiledAsyncBotbase.Stop;
            _onButtonPress = compiledAsyncBotbase.OnButtonPress;
            _pulseFlags = compiledAsyncBotbase.PulseFlags;
            _wantButton = compiledAsyncBotbase.WantButton;
            _requiresProfile = compiledAsyncBotbase.RequiresProfile;
            _isAutonomous = compiledAsyncBotbase.IsAutonomous;
            _getRoot = compiledAsyncBotbase.GetRoot;

        }


        private static Assembly LoadAssembly(string path)
        {
            if (!File.Exists(path))
            {
                return null;
            }

            Assembly assembly = null;
            try
            {
                assembly = Assembly.LoadFrom(path);
            }
            catch (Exception e)
            {
                Logging.WriteException(e);
            }

            return assembly;
        }

        private static void RedirectAssembly()
        {
            AppDomain.CurrentDomain.AssemblyResolve += (sender, args) =>
            {
                var name = Assembly.GetEntryAssembly()?.GetName().Name;
                var requestedAssembly = new AssemblyName(args.Name);
                return requestedAssembly.Name != name ? null : Assembly.GetEntryAssembly();
            };


            AppDomain.CurrentDomain.AssemblyResolve += (sender, args) =>
            {
                var requestedAssembly = new AssemblyName(args.Name);
                return requestedAssembly.Name != "GreyMagic" ? null : Core.Memory.GetType().Assembly;
            };


            AppDomain.CurrentDomain.AssemblyResolve += (sender, args) =>
            {
                var requestedAssembly = new AssemblyName(args.Name);
                return requestedAssembly.Name != "LlamaLibrary" ? null : typeof(OffsetManager).Assembly;
            };

            AppDomain.CurrentDomain.AssemblyResolve += (sender, args) =>
            {
                var requestedAssembly = new AssemblyName(args.Name);
                return requestedAssembly.Name != "Newtonsoft" ? null : typeof(JsonContract).Assembly;
            };
        }
    }
}